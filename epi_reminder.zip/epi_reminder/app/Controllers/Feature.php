<?php namespace App\Controllers;

class Feature extends BaseController
{
	public function feature()
	{
         echo view('templates/header');
         echo view('feature');
		 echo view('templates/footer');
		
	}
}
