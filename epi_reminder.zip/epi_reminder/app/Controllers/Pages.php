<?php namespace App\Controllers;

class Pages extends BaseController
{
	public function index()
	{
         echo view('templates/header');
         echo view('home');
		 echo view('templates/footer');
		
	}
	public function feature()
	{
         echo view('templates/header');
         echo view('feature');
		 echo view('templates/footer');
		
	}
}
