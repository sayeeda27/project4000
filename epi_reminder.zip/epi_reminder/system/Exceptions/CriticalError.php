<?php namespace CodeIgniter\Exceptions;

/**
 * Error: Critical conditions, like component unavailble, etc.
 */

class CriticalError extends \Error
{

}
